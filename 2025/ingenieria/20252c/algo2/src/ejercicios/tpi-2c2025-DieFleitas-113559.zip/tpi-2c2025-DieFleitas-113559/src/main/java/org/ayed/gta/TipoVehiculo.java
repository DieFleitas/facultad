package org.ayed.gta;

public enum TipoVehiculo {
    AUTO,
    MOTO
}
