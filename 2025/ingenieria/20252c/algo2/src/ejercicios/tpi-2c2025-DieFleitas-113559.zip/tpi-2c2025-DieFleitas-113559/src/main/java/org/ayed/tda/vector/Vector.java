package org.ayed.tda.vector;

public class Vector<T> {
    private T[] datos;
    private int tamanioFisico;
    private int tamanioLogico;

    /**
     * Constructor de Vector.
     */
    @SuppressWarnings("unchecked")
    public Vector() {
        this.datos = (T[]) new Object[0];
        this.tamanioFisico = 0;
        this.tamanioLogico = 0;
    }

    /**
     * Constructor de copia de Vector.
     *
     * @param vector Vector a copiar.
     *               No puede ser nulo.
     * @throws ExcepcionVector si el vector es nulo.
     */
    @SuppressWarnings("unchecked")
    public Vector(Vector<T> vector) {
        if (vector == null) throw new ExcepcionVector("Vector nulo");
        this.tamanioFisico = vector.tamanioFisico;
        this.tamanioLogico = vector.tamanioLogico;
        this.datos = (T[]) new Object[this.tamanioFisico];
        if (this.tamanioLogico >= 0) {
            System.arraycopy(vector.datos, 0, this.datos, 0, this.tamanioLogico);
        }
    }

    /**
     * Agrega un dato al final del vector.
     *
     * @param dato Dato a agregar.
     */
    public void agregar(T dato) {
        asegurarCapacidadInterna(tamanioLogico + 1);
        datos[tamanioLogico++] = dato;
    }

    /**
     * Agrega un dato al vector en el índice indicado.
     * <p>
     * Ejemplo:
     * <pre>
     * {@code
     * >> [1, 3, 2, 7, 0]
     * agregar(9, 2);
     * >> [1, 3, 9, 2, 7, 0]
     * }
     * </pre>
     *
     * @param dato   Dato a agregar.
     * @param indice Índice en el que se inserta el dato.
     *               No puede ser negativo.
     *               No puede ser mayor que el tamaño del vector.
     * @throws ExcepcionVector si el índice no es válido.
     */
    public void agregar(T dato, int indice) {
        if (indice < 0 || indice > tamanioLogico) throw new ExcepcionVector("Indice invalido");
        asegurarCapacidadInterna(tamanioLogico + 1);
        for (int i = tamanioLogico; i > indice; i--) {
            datos[i] = datos[i - 1];
        }
        datos[indice] = dato;
        tamanioLogico++;
    }

    /**
     * Elimina el último dato del vector.
     *
     * @return el dato eliminado.
     * @throws ExcepcionVector si el vector está vacío.
     */
    public T eliminar() {
        if (tamanioLogico == 0) throw new ExcepcionVector("Vector vacio");
        T valor = datos[tamanioLogico - 1];
        datos[tamanioLogico - 1] = null;
        tamanioLogico--;
        reducirSiCorresponde();
        return valor;
    }

    /**
     * Elimina el dato del vector en el índice indicado.
     * <p>
     * Ejemplo:
     * <pre>
     * {@code
     * >> [1, 3, 2, 7, 0]
     * eliminar(1);
     * >> [1, 2, 7, 0]
     * }
     * </pre>
     *
     * @param indice Índice del dato a eliminar.
     *               No puede ser negativo.
     *               No puede ser mayor o igual que el tamaño del vector.
     * @return el dato eliminado.
     * @throws ExcepcionVector si el vector está vacío,
     *                         o si el índice no es válido.
     */
    public T eliminar(int indice) {
        if (tamanioLogico == 0) throw new ExcepcionVector("Vector vacio");
        if (indice < 0 || indice >= tamanioLogico) throw new ExcepcionVector("Indice invalido");
        T valor = datos[indice];
        for (int i = indice; i < tamanioLogico - 1; i++) {
            datos[i] = datos[i + 1];
        }
        datos[tamanioLogico - 1] = null;
        tamanioLogico--;
        reducirSiCorresponde();
        return valor;
    }

    /**
     * Obtiene el dato del vector en el índice indicado.
     *
     * @param indice Índice del dato a obtener.
     *               No puede ser negativo.
     *               No puede ser mayor o igual que el tamaño del vector.
     * @return el dato en el índice indicado.
     * @throws ExcepcionVector si el índice no es válido.
     */
    public T dato(int indice) {
        if (indice < 0 || indice >= tamanioLogico) throw new ExcepcionVector("Indice invalido");
        return datos[indice];
    }

    /**
     * Modifica el dato del vector en el índice indicado
     * por el dato indicado por parámetro.
     *
     * @param indice Índice del dato a modificar.
     *               No puede ser negativo.
     *               No puede ser mayor o igual que el tamaño del vector.
     * @throws ExcepcionVector si el índice no es válido.
     */
    public void modificarDato(T dato, int indice) {
        if (tamanioLogico == 0) throw new ExcepcionVector("Vector vacio");
        if (indice < 0 || indice >= tamanioLogico) throw new ExcepcionVector("Indice invalido");
        datos[indice] = dato;
    }

    /**
     * Obtiene el tamaño del vector.
     *
     * @return el tamaño del vector.
     */
    public int tamanio() {
        return tamanioLogico;
    }

    /**
     * Obtiene el tamaño máximo del vector.
     * <p>
     * NOTA: Este método es únicamente para probar
     * el TDA.
     *
     * @return el tamaño máximo del vector.
     */
    public int tamanioMaximo() {
        return tamanioFisico;
    }

    /**
     * Evalúa si el vector está vacío.
     *
     * @return true si el vector está vacío.
     */
    public boolean vacio() {
        return tamanioLogico == 0;
    }


    /* ------------------ Helpers privados ------------------ */

    /**
     * Asegura que el arreglo interno tenga al menos la capacidad mínima requerida.
     *
     * @param minRequerido la capacidad mínima que debe alcanzarse (>= 0)
     */
    @SuppressWarnings("unchecked")
    private void asegurarCapacidadInterna(int minRequerido) {
        if (tamanioFisico >= minRequerido) return;
        int nuevaCap = Math.max(1, tamanioFisico * 2);
        while (nuevaCap < minRequerido) nuevaCap *= 2;
        // copiar a nuevo arreglo
        T[] nuevosDatos = (T[]) new Object[nuevaCap];
        for (int i = 0; i < tamanioLogico; i++) nuevosDatos[i] = datos[i];
        datos = nuevosDatos;
        tamanioFisico = nuevaCap;
    }

    /**
     * Redimensiona el arreglo interno a la nueva capacidad indicada.
     *
     * @param nuevaCap la nueva capacidad física a asignar (debe ser >= tamanioLogico)
     */
    @SuppressWarnings("unchecked")
    private void redimensionar(int nuevaCap) {
        T[] nuevosDatos = (T[]) new Object[nuevaCap];
        if (tamanioLogico >= 0) System.arraycopy(datos, 0, nuevosDatos, 0, tamanioLogico);
        datos = nuevosDatos;
        tamanioFisico = nuevaCap;
    }

    /**
     * Reduce la capacidad física si corresponde: cuando hay demasiada memoria libre
     * (es decir, cuando {@code tamanioLogico <= tamanioFisico/2} y {@code tamanioFisico > 1})
     * se reduce la capacidad a la mitad.
     */
    private void reducirSiCorresponde() {
        if (tamanioFisico <= 1) return;
        if (tamanioLogico <= tamanioFisico / 2) {
            int nuevaCap = Math.max(1, tamanioFisico / 2);
            if (nuevaCap < tamanioLogico) nuevaCap = tamanioLogico;
            if (nuevaCap != tamanioFisico) redimensionar(nuevaCap);
        }
    }
}
