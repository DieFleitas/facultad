[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/qtf0yWts)
# TPI - 2c2025 - El Garaje

<p align="center">
   <img src="TPI-2c2025.png" alt="TPI-2c2025"><br>
</p>

El proyecto está configurado usando [Maven](https://maven.apache.org/),
y puede ser compilado, empaquetado y probado fácilmente usando los siguientes comandos:

### Compilar

```
mvn compile
```

### Empaquetar

```
mvn package
```

### Pruebas

```
mvn test
```

## Aclaraciones para el corrector

#### Escogí Vector dinamico para el Garaje por estas razones:

- Con Vector dinamico puedo expandir la capacidad. Con Vector estatico habría que recrear un vector estático más grande y copiar todo, pero menos flexible.
