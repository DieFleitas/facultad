package org.ayed.Menu;

import org.ayed.gta.ExcepcionGaraje;
import org.ayed.gta.Garaje;
import org.ayed.gta.TipoVehiculo;
import org.ayed.gta.Vehiculo;
import org.ayed.tda.vector.Vector;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 * Clase que implementa la interfaz de usuario (menú) para interactuar con un Garaje.
 */
public class Menu {

    private final Garaje garaje;
    private final Scanner scanner;
    private boolean salir = false;

    /**
     * Crea un menú asociado a un garaje y a un Scanner para entrada por consola.
     *
     * @param garaje  garaje sobre el cual se ejecutarán las operaciones
     * @param scanner scanner usado para leer la entrada del usuario
     */
    public Menu(Garaje garaje, Scanner scanner) {
        this.garaje = garaje;
        this.scanner = scanner;
    }

    /**
     * Inicia el bucle principal del menú hasta que el usuario decide salir.
     */
    public void run() {
        while (!salir) {
            mostrarMenu();
            int opcion = leerEntero("Opción: ");
            procesarOpcion(opcion);
            System.out.println();
        }
    }

    /**
     * Muestra las opciones disponibles en pantalla.
     */
    private void mostrarMenu() {
        System.out.println("=== GARAGE MENU ===");
        System.out.println("1) Agregar vehículo");
        System.out.println("2) Listar vehículos");
        System.out.println("3) Eliminar vehículo (por nombre)");
        System.out.println("4) Mejorar garaje (50 créditos)");
        System.out.println("5) Agregar créditos");
        System.out.println("6) Mostrar valor total");
        System.out.println("7) Mostrar costo mantenimiento diario");
        System.out.println("8) Exportar a CSV");
        System.out.println("9) Cargar desde CSV");
        System.out.println("0) Salir");
    }

    /**
     * Procesa la opción seleccionada por el usuario y delega a la acción correspondiente.
     *
     * @param op opción numérica ingresada por el usuario
     */
    private void procesarOpcion(int op) {
        switch (op) {
            case 1: accionAgregar(); break;
            case 2: accionListar(); break;
            case 3: accionEliminar(); break;
            case 4: accionMejorar(); break;
            case 5: accionAgregarCreditos(); break;
            case 6: accionMostrarValorTotal(); break;
            case 7: accionMostrarCosto(); break;
            case 8: accionExportar(); break;
            case 9: accionCargar(); break;
            case 0: salir = true; System.out.println("Saliendo..."); break;
            default: System.out.println("Opción inválida. Intente nuevamente."); break;
        }
    }

    /* -------------------- Acciones del menú -------------------- */

    /**
     * Solicita los datos al usuario y agrega un nuevo vehículo al garaje.
     */
    private void accionAgregar() {
        System.out.println("[AGREGAR VEHÍCULO]");
        String nombre = leerString("Nombre: ");
        TipoVehiculo tipo = leerTipoVehiculo();
        int precio = leerEntero("Precio (entero): ");
        int litros = leerEntero("Capacidad de gasolina (litros, entero): ");
        try {
            Vehiculo vehiculo = new Vehiculo(nombre, tipo, precio, litros);
            garaje.agregarVehiculo(vehiculo);
            System.out.println("Vehículo agregado correctamente.");
        } catch (ExcepcionGaraje eg) {
            System.out.println("No se pudo agregar vehículo: " + eg.getMessage());
        } catch (IllegalArgumentException iae) {
            System.out.println("Datos inválidos: " + iae.getMessage());
        }
    }

    /**
     * Muestra por pantalla la lista de vehículos almacenados en el garaje.
     */
    private void accionListar() {
        System.out.println("[LISTA DE VEHÍCULOS]");
        Vector<Vehiculo> vehiculos = garaje.listarVehiculos();
        int tamanio = garaje.cantidadVehiculos();
        if (tamanio == 0) {
            System.out.println("Garaje vacío.");
            return;
        }
        for (int i = 0; i < tamanio; i++) {
            Vehiculo vehiculo = vehiculos.dato(i);
            System.out.printf("%d) %s%n", i + 1, vehiculo.toString());
        }
    }

    /**
     * Solicita un nombre y elimina el vehículo correspondiente del garaje.
     */
    private void accionEliminar() {
        System.out.println("[ELIMINAR VEHÍCULO]");
        String nombre = leerString("Nombre del vehículo a eliminar: ");
        try {
            garaje.eliminarVehiculo(nombre);
            System.out.println("Vehículo eliminado.");
        } catch (ExcepcionGaraje eg) {
            System.out.println("No se pudo eliminar: " + eg.getMessage());
        }
    }

    /**
     * Intenta mejorar el garaje consumiendo créditos (50).
     */
    private void accionMejorar() {
        System.out.println("[MEJORAR GARAGE]");
        try {
            garaje.mejorarGaraje();
            System.out.println("Garaje mejorado. Nueva capacidad: " + garaje.capacidadActual()
                    + ". Créditos restantes: " + garaje.obtenerCreditos());
        } catch (ExcepcionGaraje eg) {
            System.out.println("No se pudo mejorar: " + eg.getMessage());
        }
    }

    /**
     * Pide al usuario una cantidad y la agrega como créditos al garaje.
     */
    private void accionAgregarCreditos() {
        int creditos = leerEntero("Cantidad de créditos a agregar: ");
        try {
            garaje.agregarCreditos(creditos);
            System.out.println("Créditos agregados. Total: " + garaje.obtenerCreditos());
        } catch (ExcepcionGaraje eg) {
            System.out.println("No se pudieron agregar créditos: " + eg.getMessage());
        }
    }

    /**
     * Muestra por pantalla el valor total (suma de precios) del garaje.
     */
    private void accionMostrarValorTotal() {
        System.out.println("Valor total del garaje: " + garaje.obtenerValorTotal());
    }

    /**
     * Muestra por pantalla el costo de mantenimiento diario total del garaje.
     */
    private void accionMostrarCosto() {
        System.out.println("Costo de mantenimiento diario: " + garaje.obtenerCostoMantenimiento());
    }

    /**
     * Pide una ruta y exporta el estado del garaje a un archivo CSV validado.
     */
    private void accionExportar() {
        System.out.println("[EXPORTAR CSV]");
        String ruta = leerString("Ruta de salida (ej: garaje.csv): ");
        if (ruta.isEmpty()) {
            System.out.println("Ruta vacía. Operación cancelada.");
            return;
        }
        if (!validarRutaSalida(ruta)) return;
        try {
            garaje.exportarCSV(ruta);
            System.out.println("Exportado a " + ruta);
        } catch (IOException e) {
            System.out.println("Error al exportar: " + e.getMessage());
        }
    }

    /**
     * Pide una ruta y carga el estado del garaje desde un archivo CSV validado.
     */
    private void accionCargar() {
        System.out.println("[CARGAR CSV]");
        String ruta = leerString("Ruta de archivo (ej: garaje.csv): ");
        if (ruta.isEmpty()) {
            System.out.println("Ruta vacía. Operación cancelada.");
            return;
        }
        if (!validarRutaEntrada(ruta)) return;
        try {
            int agregados = garaje.cargarCSV(ruta);
            System.out.println("Se agregaron " + agregados + " vehículos desde el archivo.");
        } catch (IOException e) {
            System.out.println("Error al leer archivo: " + e.getMessage());
        }
    }

    /* -------------------- Lectura de datos -------------------- */

    /**
     * Lee un entero desde la entrada del usuario. Repite hasta que se ingrese un entero válido.
     *
     * @param prompt mensaje a mostrar al usuario
     * @return entero ingresado por el usuario
     */
    private int leerEntero(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Ingrese un número entero.");
            }
        }
    }

    /**
     * Lee una línea de texto desde la entrada del usuario y la devuelve 'limpia'.
     *
     * @param prompt mensaje a mostrar al usuario
     * @return cadena ingresada (trimmed)
     */
    private String leerString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    /**
     * Lee y valida el tipo de vehículo ingresado por el usuario.
     * Repite hasta recibir "AUTO" o "MOTO".
     *
     * @return TipoVehiculo seleccionado por el usuario
     */
    private TipoVehiculo leerTipoVehiculo() {
        while (true) {
            System.out.print("Tipo (AUTO/MOTO): ");
            String input = scanner.nextLine().trim().toUpperCase();
            try {
                return TipoVehiculo.valueOf(input);
            } catch (IllegalArgumentException e) {
                System.out.println("Tipo inválido. Ingrese 'AUTO' o 'MOTO'.");
            }
        }
    }

    /** Comprueba si la ruta tiene extensión .csv (case-insensitive). */
    private boolean esCsv(String ruta) {
        if (ruta == null) return false;
        return ruta.toLowerCase().endsWith(".csv");
    }

    /**
     * Valida la ruta de entrada para cargar:
     *  - debe ser .csv
     *  - debe existir, ser fichero y ser legible
     */
    private boolean validarRutaEntrada(String ruta) {
        if (!esCsv(ruta)) {
            System.out.println("El archivo debe tener extensión .csv");
            return false;
        }
        File f = new File(ruta);
        if (!f.exists()) {
            System.out.println("El archivo no existe: " + ruta);
            return false;
        }
        if (!f.isFile()) {
            System.out.println("La ruta no es un archivo valido: " + ruta);
            return false;
        }
        if (!f.canRead()) {
            System.out.println("No se puede leer el archivo: " + ruta);
            return false;
        }
        return true;
    }

    /**
     * Valida la ruta de salida para exportar:
     *  - debe ser .csv
     *  - su directorio padre debe existir y ser escribible
     *  - si el archivo existe pregunta confirmación para sobrescribir
     */
    private boolean validarRutaSalida(String ruta) {
        if (!esCsv(ruta)) {
            System.out.println("El archivo de salida debe tener extensión .csv");
            return false;
        }
        File archivo = new File(ruta);
        File padre = archivo.getAbsoluteFile().getParentFile();
        if (padre == null) {
            padre = new File(".");
        }
        if (!padre.exists()) {
            System.out.println("El directorio padre no existe: " + padre.getPath());
            return false;
        }
        if (!padre.canWrite()) {
            System.out.println("No hay permisos de escritura en el directorio: " + padre.getPath());
            return false;
        }
        if (archivo.exists()) {
            String r = leerString("El archivo ya existe. ¿Sobrescribir? (s/n): ");
            if (!r.trim().toLowerCase().startsWith("s")) {
                System.out.println("Operación cancelada por el usuario.");
                return false;
            }
        }
        return true;
    }
}
