package org.ayed;

import org.ayed.Menu.Menu;
import org.ayed.gta.Garaje;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Garaje garaje = new Garaje();
        try (Scanner scanner = new Scanner(System.in)) {
            Menu menu = new Menu(garaje, scanner);
            menu.run();
        }
        System.out.println("Programa finalizado.");
    }
}
