package org.ayed.gta;

import org.ayed.tda.vector.Vector;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Garaje {
    private static final int CAPACIDAD_INICIAL = 5;
    private static final int COSTO_MEJORA = 50;
    private static final int COSTO_POR_LITRO = 1;
    private static final int COSTO_POR_RUEDA_AUTO = 50;
    private static final int COSTO_POR_RUEDA_MOTO = 30;

    private final Vector<Vehiculo> vehiculos;
    private int creditos;
    private int capacidadMaxima;

    /**
     * Constructor: crea un garaje vacío con la capacidad inicial predefinida.
     */
    public Garaje() {
        this.vehiculos = new Vector<>();
        this.creditos = 0;
        this.capacidadMaxima = CAPACIDAD_INICIAL;
    }

    /**
     * Agrega un vehículo al garaje si hay espacio.
     *
     * @param vehiculo vehículo a agregar (no nulo)
     * @throws ExcepcionGaraje si vehiculo es nulo o no hay espacio
     */
    public void agregarVehiculo(Vehiculo vehiculo) {
        if (vehiculo == null) throw new ExcepcionGaraje("Vehiculo nulo");
        if (cantidadVehiculos() >= capacidadMaxima) {
            throw new ExcepcionGaraje("No hay espacio en el garaje");
        }
        vehiculos.agregar(vehiculo);
    }

    /**
     * Elimina el primer vehículo cuyo nombre coincida.
     *
     * @param nombre nombre del vehículo a eliminar
     * @throws ExcepcionGaraje si nombre inválido o vehículo no encontrado
     */
    public void eliminarVehiculo(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) throw new ExcepcionGaraje("Nombre inválido");
        int idx = buscarIndicePorNombre(nombre);
        if (idx == -1) throw new ExcepcionGaraje("No existe vehículo con ese nombre");
        vehiculos.eliminar(idx);
    }

    /**
     * Agrega créditos al garaje.
     *
     * @param creditos cantidad de créditos a sumar (>0)
     * @throws ExcepcionGaraje si creditos <= 0
     */
    public void agregarCreditos(int creditos) {
        if (creditos <= 0) throw new ExcepcionGaraje("Creditos invalidos");
        this.creditos += creditos;
    }

    /**
     * Mejora la capacidad del garaje consumiendo 50 créditos.
     *
     * @throws ExcepcionGaraje si no hay créditos suficientes
     */
    public void mejorarGaraje() {
        if (this.creditos < COSTO_MEJORA) throw new ExcepcionGaraje("Creditos insuficientes");
        this.creditos -= COSTO_MEJORA;
        this.capacidadMaxima += 1;
    }

    /**
     * Calcula y devuelve la suma de los precios de todos los vehículos del garaje.
     *
     * @return suma de precios (0 si no hay vehículos)
     */
    public int obtenerValorTotal() {
        int suma = 0;
        for (int i = 0; i < cantidadVehiculos(); i++) {
            suma += vehiculos.dato(i).obtenerPrecio();
        }
        return suma;
    }

    /**
     * Calcula el costo de mantenimiento diario sumando el coste por ruedas y por litros
     * de cada vehículo según su tipo.
     *
     * @return costo total diario
     */
    public int obtenerCostoMantenimiento() {
        int suma = 0;
        for (int i = 0; i < cantidadVehiculos(); i++) {
            Vehiculo vehiculo = vehiculos.dato(i);
            int costoRueda = (vehiculo.obtenerTipo() == TipoVehiculo.AUTO) ? COSTO_POR_RUEDA_AUTO : COSTO_POR_RUEDA_MOTO;
            suma += costoRueda * vehiculo.obtenerCantidadRuedas();
            suma += COSTO_POR_LITRO * vehiculo.obtenerCapacidadGasolina();
        }
        return suma;
    }

    /**
     * Devuelve una copia del Vector interno con los vehículos actuales.
     *
     * @return copia del Vector<Vehiculo> con los vehículos en orden
     */
    public Vector<Vehiculo> listarVehiculos() {
        return new Vector<>(this.vehiculos);
    }

    /**
     * Vacía completamente el garaje eliminando todos los vehículos almacenados.
     */
    public void vaciarGaraje() {
        while (cantidadVehiculos() > 0) {
            vehiculos.eliminar();
        }
    }

    /**
     * Exporta el estado del garaje a CSV.
     * Formato:
     *  primera línea: CAPACIDAD_MÁXIMA,CRÉDITOS
     *  luego: NOMBRE,PRECIO,TIPO,CANTIDAD_RUEDAS,CAPACIDAD_GASOLINA
     *
     * @param ruta ruta del archivo a escribir
     * @throws IOException si hay error de escritura
     */
    public void exportarCSV(String ruta) throws IOException {
        try (FileWriter fw = new FileWriter(ruta)) {
            fw.write(this.capacidadMaxima + "," + this.creditos + System.lineSeparator());

            for (int i = 0; i < cantidadVehiculos(); i++) {
                Vehiculo vehiculo = vehiculos.dato(i);
                String linea = String.format("%s,%d,%s,%d,%d",
                        vehiculo.obtenerNombre(),
                        vehiculo.obtenerPrecio(),
                        vehiculo.obtenerTipo().name(),
                        vehiculo.obtenerCantidadRuedas(),
                        vehiculo.obtenerCapacidadGasolina());
                fw.write(linea + System.lineSeparator());
            }
        } catch (IOException e) {
            throw new IOException(e);
        }
    }

    /**
     * Carga el archivo CSV con el formato esperado.
     * - Primera línea: CAPACIDAD_MÁXIMA,CRÉDITOS
     * - Líneas siguientes: NOMBRE,PRECIO,TIPO,CANTIDAD_RUEDAS,CAPACIDAD_GASOLINA
     *
     * @param ruta ruta del archivo a leer
     * @return cantidad de vehículos agregados desde el archivo
     * @throws IOException si hay error de lectura del archivo
     */
    public int cargarCSV(String ruta) throws IOException {
        int agregados = 0;

        try (FileReader fr = new FileReader(ruta)) {
            Scanner scanner = new Scanner(fr);
            if (scanner.hasNextLine()) {
                String encabezado = scanner.nextLine().trim();
                if (!encabezado.isEmpty()) {
                    procesarEncabezado(encabezado);
                }
            }

            this.vaciarGaraje();

            while (scanner.hasNextLine()) {
                if (cantidadVehiculos() >= capacidadMaxima) break;
                String linea = scanner.nextLine().trim();
                Vehiculo vehiculo = null;
                if (!(linea.isEmpty())) {
                    vehiculo = crearVehiculoDesdeLinea(linea);
                }

                if (vehiculo != null) {
                    vehiculos.agregar(vehiculo);
                    agregados++;
                }
            }
        }
        return agregados;
    }

    /* ---------------- helpers ---------------- */

    /**
     * Busca índice del primer vehículo con el nombre.
     * Retorna -1 si no existe.
     */
    private int buscarIndicePorNombre(String nombre) {
        if (nombre == null) return -1;
        String objetivo = nombre.trim().toLowerCase();
        for (int i = 0; i < vehiculos.tamanio(); i++) {
            Vehiculo vehiculo = vehiculos.dato(i);
            if (vehiculo.obtenerNombre().toLowerCase().equals(objetivo)) return i;
        }
        return -1;
    }

    /**
     * Devuelve la cantidad de créditos disponibles en el garaje.
     *
     * @return créditos actuales
     */
    public int obtenerCreditos() { return creditos; }

    /**
     * Devuelve la capacidad actual del garaje (número de plazas).
     *
     * @return capacidad máxima (plazas)
     */
    public int capacidadActual() { return capacidadMaxima; }

    /**
     * Devuelve la cantidad de vehículos actualmente almacenados.
     *
     * @return número de vehículos
     */
    public int cantidadVehiculos() { return vehiculos.tamanio(); }

    /**
     * Procesa la primera línea (encabezado) con formato "CAPACIDAD,CRÉDITOS".
     * Si la línea está malformada, la función imprime un mensaje y no realiza cambios.
     *
     * @param encabezado la primera línea del archivo (trimmed)
     */
    private void procesarEncabezado(String encabezado) {
        String[] partes = encabezado.split(",", -1);
        if (partes.length < 2) {
            System.out.println("Encabezado mal formado (se esperaba 'CAPACIDAD,CRÉDITOS'): " + encabezado);
            return;
        }
        try {
            int archivoCap = Integer.parseInt(partes[0].trim());
            int archivoCred = Integer.parseInt(partes[1].trim());
            this.capacidadMaxima = archivoCap;
            this.creditos = archivoCred;
        } catch (NumberFormatException e) {
            System.out.println("Encabezado con números inválidos: " + encabezado);
        }
    }

    /**
     * Intenta crear un Vehiculo a partir de una línea CSV.
     * Formato esperado: NOMBRE,PRECIO,TIPO,CANTIDAD_RUEDAS,CAPACIDAD_GASOLINA
     * - Si la línea es válida devuelve el Vehiculo;
     * - Si hay algún error (parseo, tipo inválido, datos negativos) devuelve null e imprime un mensaje.
     *
     * @param linea la línea CSV
     * @return Vehiculo creado o null si la línea es inválida
     */
    private Vehiculo crearVehiculoDesdeLinea(String linea) {
        String[] campos = linea.split(",", -1);
        if (campos.length < 5) {
            System.out.println("Linea malformada (campos insuficientes): " + linea);
            return null;
        }

        try {
            String nombre = campos[0].trim();
            int precio = Integer.parseInt(campos[1].trim());
            String tipoStr = campos[2].trim();
            int litros = Integer.parseInt(campos[4].trim());

            TipoVehiculo tipo;
            try {
                tipo = TipoVehiculo.valueOf(tipoStr.toUpperCase());
            } catch (IllegalArgumentException iae) {
                System.out.println("TipoVehiculo inválido en línea: " + linea);
                return null;
            }

            if (nombre.isEmpty()) {
                System.out.println("Nombre vacío en línea: " + linea);
                return null;
            }
            if (precio < 0 || litros < 0) {
                System.out.println("Valores negativos en línea: " + linea);
                return null;
            }

            return new Vehiculo(nombre, tipo, precio, litros);

        } catch (NumberFormatException e) {
            System.out.println("Error al parsear número en línea: " + linea);
            return null;
        } catch (Exception e) {
            System.out.println("Error procesando línea: " + linea + " -> " + e.getMessage());
            return null;
        }
    }
}
