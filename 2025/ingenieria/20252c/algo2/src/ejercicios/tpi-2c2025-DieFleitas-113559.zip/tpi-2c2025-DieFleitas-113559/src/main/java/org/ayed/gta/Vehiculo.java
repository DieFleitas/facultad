package org.ayed.gta;

public class Vehiculo {
    private final String nombre;
    private final TipoVehiculo tipo;
    private final int precio;
    private final int capacidadGasolina;
    private final int cantidadRuedas;

    /**
     * Constructor.
     *
     * @param nombre            nombre no nulo y no vacío
     * @param tipo              tipo (AUTO o MOTO), no nulo
     * @param precio            precio >= 0
     * @param capacidadGasolina capacidad en litros >= 0
     * @throws IllegalArgumentException si algún parámetro inválido
     */
    public Vehiculo(String nombre, TipoVehiculo tipo, int precio, int capacidadGasolina) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre inválido");
        }
        if (tipo == null) {
            throw new IllegalArgumentException("Tipo inválido");
        }
        if (precio < 0) {
            throw new IllegalArgumentException("Precio negativo");
        }
        if (capacidadGasolina < 0) {
            throw new IllegalArgumentException("Capacidad de gasolina negativa");
        }
        this.nombre = nombre.trim();
        this.tipo = tipo;
        this.precio = precio;
        this.capacidadGasolina = capacidadGasolina;
        if (tipo == TipoVehiculo.AUTO) this.cantidadRuedas = 4;
        else this.cantidadRuedas = 2;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public TipoVehiculo obtenerTipo() {
        return tipo;
    }

    public int obtenerPrecio() {
        return precio;
    }

    public int obtenerCapacidadGasolina() {
        return capacidadGasolina;
    }

    public int obtenerCantidadRuedas() {
        return cantidadRuedas;
    }

    @Override
    public String toString() {
        return String.format("%s (tipo=%s, precio=%d, ruedas=%d, litros=%d)",
                nombre, tipo, precio, cantidadRuedas, capacidadGasolina);
    }
}
